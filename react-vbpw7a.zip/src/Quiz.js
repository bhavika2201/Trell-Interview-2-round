import React from 'react';
import { render } from 'react-dom';
//import Hello from './Hello';
//import './style.css';
import Quiz from './Quiz';
//import ReactDOM from 'react-dom';
function App()
{
  return (
    <div>
    <Quiz></Quiz>
    </div>
  )
}
//export default App
const rootEle=document.getElementById('root')
ReactDOM.render()